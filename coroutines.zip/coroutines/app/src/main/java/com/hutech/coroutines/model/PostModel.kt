package com.hutech.coroutines.model

data class PostModel (
    var userId:Int?=0,
    var id:Int?=0,
    var title:String?="",
    var body:String?=""
    )